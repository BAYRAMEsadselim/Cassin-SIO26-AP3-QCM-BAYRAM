// Script principal
