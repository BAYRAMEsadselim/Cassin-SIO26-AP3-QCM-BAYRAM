<?php
// Point d'entrée de l'application
require __DIR__ . '/../vendor/autoload.php';

// TODO : instancier le Router et dispatcher la requête
