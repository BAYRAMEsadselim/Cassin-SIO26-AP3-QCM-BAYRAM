<?php
return [
    'host' => 'localhost',
    'dbname' => 'qcm_db',
    'user' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
