<?php
return [
    'app_name' => 'Plateforme QCM',
    'env' => 'development',
];
