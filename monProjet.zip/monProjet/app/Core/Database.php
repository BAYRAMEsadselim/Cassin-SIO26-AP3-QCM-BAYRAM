<?php

namespace App\Core;

class Database
{
    // TODO : connexion PDO à MariaDB
}
