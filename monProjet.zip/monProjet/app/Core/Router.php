<?php

namespace App\Core;

class Router
{
    // TODO : routage des requêtes vers les contrôleurs
}
