<?php

namespace App\Security;

class Permission
{
    // TODO
}
