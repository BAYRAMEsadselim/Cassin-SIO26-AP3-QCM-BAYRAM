<?php

namespace App\Security;

class Authorization
{
    // TODO
}
