<?php

namespace App\Controllers;

class UserController
{
    // TODO : CRUD des comptes utilisateurs
}
