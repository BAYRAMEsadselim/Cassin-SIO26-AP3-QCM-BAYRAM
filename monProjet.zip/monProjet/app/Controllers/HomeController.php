<?php

namespace App\Controllers;

class HomeController
{
    // TODO
}
