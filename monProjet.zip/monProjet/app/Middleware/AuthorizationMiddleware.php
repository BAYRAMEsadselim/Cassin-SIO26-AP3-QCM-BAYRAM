<?php

namespace App\Middleware;

class AuthorizationMiddleware implements MiddlewareInterface
{
    public function handle()
    {
        // TODO : vérifier les droits
    }
}
