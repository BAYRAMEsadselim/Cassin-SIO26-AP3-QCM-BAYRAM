<?php

namespace App\Middleware;

class AuthMiddleware implements MiddlewareInterface
{
    public function handle()
    {
        // TODO : vérifier que l'utilisateur est connecté
    }
}
