<?php

namespace App\Middleware;

class CsrfMiddleware implements MiddlewareInterface
{
    public function handle()
    {
        // TODO : protection CSRF
    }
}
