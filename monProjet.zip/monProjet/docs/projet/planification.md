---
title: Planification du projet
author: 
creator: Typora inc.
subject: Gestion de projet
header:
footer: ${title} - ${author} - Page ${pageNo} / ${totalPages}
---
# Planification du projet

------

**Date de création** : 
**Date de modification** : 
**Sommaire :**

> [TOC]

<div style="page-break-after:always"></div>

## 1. Diagramme de GANTT

(à intégrer ici)

## 2. Étapes et tâches dans GitHub

(capture d'écran + description)
