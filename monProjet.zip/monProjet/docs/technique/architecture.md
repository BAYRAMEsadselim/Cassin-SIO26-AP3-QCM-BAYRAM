---
title: Étude technique - Architecture
author: 
creator: Typora inc.
subject: Documentation technique
header:
footer: ${title} - ${author} - Page ${pageNo} / ${totalPages}
---
# Étude technique - Architecture

------

**Date de création** : 
**Date de modification** : 
**Sommaire :**

> [TOC]

<div style="page-break-after:always"></div>

## 1. Prérequis d'installation

## 2. Normes de codage et conventions

## 3. Diagramme de contexte statique

## 4. Diagramme de cas d'utilisation

## 5. Modèle entité-association / diagramme de classes

## 6. Diagramme de classes de l'application

## 7. Maquettes
