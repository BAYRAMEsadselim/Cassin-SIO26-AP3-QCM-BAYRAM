---
title: Rapport d'utilisation de l'IA
author: 
creator: Typora inc.
subject: Documentation technique
header:
footer: ${title} - ${author} - Page ${pageNo} / ${totalPages}
---
# Rapport d'utilisation de l'IA

------

**Date de création** : 
**Date de modification** : 
**Sommaire :**

> [TOC]

<div style="page-break-after:always"></div>

## 1. Méthode de travail avec l'IA

## 2. Instructions IA formulées

## 3. Références des commits / documents réalisés avec l'aide de l'IA
