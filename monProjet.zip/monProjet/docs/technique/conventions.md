---
title: Conventions et normes
author: 
creator: Typora inc.
subject: Documentation technique
header:
footer: ${title} - ${author} - Page ${pageNo} / ${totalPages}
---
# Conventions et normes

------

**Date de création** : 
**Date de modification** : 
**Sommaire :**

> [TOC]

<div style="page-break-after:always"></div>

## 1. Git / GitFlow

## 2. Conventional Commits

## 3. Normes de code (PHP-FIG, Kiwipedia)
